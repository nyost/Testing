//File: rsedu_vis.c
/*
* AUTHOR Fabian Riether
* CREATE DATE 2015/08/25
* PURPOSE This module takes care of processing images to reconstruct the drone's pose (needs specific landmark setup)
* SPECIAL NOTES
* ===============================
* Change History
* 2015/08/25 created
* ==================================
*/
#include "rsedu_vis.h"
#include <stdbool.h>



//----------------------------------
// Image processing / Vision-based pose estimation
//----------------------------------

/*
 * @input buffer Pointer to the current picture seen by the vertical camera
 * Picture is 160x120 pixels in YUYV format, ie 80x120 elements of type 'pixel2_t'
 * This functions then dumps a planar camera position estimate relative to a colored landmark setup into a fifo to make them available to the control code
 *
 * Called 60 times per second.
 */

void RSEDU_image_processing(void *buffer) {


    //process control
    static int counter = 0;

    //communication
    static float vis_data[4];
    static int vis_fifo;

    //image variables
    int c, r;
    int row, col;
    float yuv[3];
    /** the dimension of the image */
    const int nx = 80, ny = 120;
//    float feature_pps[3][4];
//    static bool matchLookupLoaded = false;
//    static unsigned char matchLookup[128][128][128];

    //camera variables
//    float camerapos[3]; //@TODO static?
//    float camerayaw;    //@TODO static?

    //Image and Matching Thresholds
    static int filtersize = 5;            //odd numbered! dummy for potential gaussian filter mask, etc.
//    int pxls_ftr_min = 5;            //minimum required nr of detected pixels per landmark

    //Landmarks, Pose Estimation Matrices
//    int lndmrk_nr = 5; //lndmrk_best = 0;
//    static lndmrk_t lndmrks[5];
    //matrices for reconstructing camera pose by intrMatrx_inv*landmark-pixellocation*ldnmrk_pinv


    //wait on first call
    if (counter == 1) {
        usleep(20000);
    }

    //Init Communication, Streaming
    int fifo;
    if (FEAT_IMSAVE == 2) {
        //u8 * raw = buffer;
    };
    pixel2_t *image = buffer;  /* Picture is a 160x120 pixels, stored in YUV422 interlaced format - TO BE CHECKED */


    /*
     * PROGRAM
     */


    //ptiming - declare and start
    //------------
    long long start;
    static FILE *ptfile;
    ptimer_start(FEAT_TIME, counter, &(start));
    //------------


    //process control
    counter++;

    if (counter == 1) {
        //ptiming - init file
        //------------
        ptimer_init(FEAT_TIME, __func__, &(ptfile), NULL);
        //------------

        printf("rsedu_vis(): Init fifo-communication...\n");

        //open fifo to dump visual position estimates to control code

        if (access("/tmp/vis_fifo", F_OK) != -1) {
            printf("rsedu_vis(): SUCCESS POSVIS FIFO exists! \n");

            vis_fifo = open("/tmp/vis_fifo", O_WRONLY);
            if (vis_fifo) {
                vis_data[0] = -99.0;
                write(vis_fifo, (float *) (&vis_data), sizeof(vis_data));
                close(vis_fifo);
                printf("rsedu_vis(): SUCCESS opening POSVIS-fifo!\n");
            } else {
                printf("rsedu_vis(): ERROR opening POSVIS-fifo!\n");
            }
        } else {
            printf("rsedu_vis(): ERROR opening POSVIS-fifo!\n");
        }


        //load lookuptable for matching process
//        if (FEAT_NOLOOK == 0) {
//            FILE *data;
//            if ((data = fopen("/data/edu/params/lookuptable.dat", "rb")) == NULL) {
//                printf("rsedu_vis(): ERROR opening lookupfile \n");
//            } else {
//                fread(matchLookup, sizeof(matchLookup), 1, data);
//                matchLookupLoaded = true;
//                fclose(data);
//            }
//        }
    }



    //landmark detection
    //------------

    //1 cycle through image, convert each pixel to hsv, threshold by s and v to find colored balls, match h value to color-closest
    // in "database" (use precomputed lookup for all these steps), save weighted average pixellocation with database-lndmrkID
    //2 reconstruct pose of camera (3D-position with yaw)


//    if (matchLookupLoaded && (FEAT_POSVIS_RUN) && ((counter % 15) == 0) && (NULL != image)) //@pseudo4Hz
//    {
//        //reset landmark matching data
//        for (c = 0; c < lndmrk_nr; c++) {
//            lndmrks[c].n = 0;
//            lndmrks[c].weights = 0;
//            lndmrks[c].px = 0;
//            lndmrks[c].py = 0;
//        }

    int margin = (int) (filtersize - 1) / 4;
    int thresh = 120;
    float x = 0;
    float y = 0;
    u_int8_t redImage[ny][nx];

    //cycle through image to get row average MIGHT NEED TO ADD THE MARGIN STUFF BACK IN.
    for (r = 0; r < ny - 2 * margin; r++) {
        for (c = 0; c < nx - 2 * margin; c++) {
            row = margin + r;
            col = margin + c;
            //Get YUV-values for pixel
            yuv[0] = (float) image[nx * row + col].y1;
//              yuv[1] = (float) image[nx * row + col].u; // don't need the u channel.
            yuv[2] = (float) image[nx * row + col].v;
            redImage[r][c] = (1.164 * (yuv[0] - 16) + 1.596 * (yuv[2] - 128)) > thresh ? 1 : 0;
        }//end inner image-for
    }//end outer image-for

    uint count = 0;
    uint xsum = 0, ysum = 0;
    // sum columns along rows
    for (r = 0; r < ny; r++) {
        for (c = 0; c < nx; c++) {
            xsum += redImage[r][c] * c;
            ysum += redImage[r][c] * r;
            count += redImage[r][c];
        }
    }

    x = (float) ((xsum / (float) count - nx / 2.0) / 10.0);
    y = (float) ((ysum / (float) count - nx / 2.0) / 10.0);


    //int rloc = rsum

    //reconstruct pose
    //-------------
    bool feature_found = true;

    if (feature_found) {
//            reconstructCameraPose(camerapos, &camerayaw, feature_pps, ldnmrk_pinv, intrMatrx_inv);
        printf("rsedu_vis(): SUCCESS reconstructed camera pose:(x=%f,y=%f)\n", x, y);


        /*
         * dump pose into FIFO to make available to controls code
         */
        //compile data
        vis_data[0] = x;
        vis_data[1] = y;
        vis_data[2] = 1;
        vis_data[3] = 0;

        vis_fifo = open("/tmp/vis_fifo", O_WRONLY);
        if (vis_fifo) {
            write(vis_fifo, (float *) (&vis_data), sizeof(vis_data));
            close(vis_fifo);
        }
    } else {
        printf("rsedu_vis(): WARNING not enough distinct markers (colored balls) found! \n");
    }



    //-----------
    //STREAMING INSTRUCTIONS
    //-----------

    /* Enabling image streaming, copies the picture into a named FIFO. Picture can then be sent to a remote Ubuntu computer using standard commands:
    
    FEAT_IMSAVE needs to be set to 2 on drone /data/edu/params/paramsEDU.dat (see GettingStarted.pdf)

    Run this one-liner in a shell on the RollingSpider (open terminal, log onto drone via telnet 192.168.1.1) :
    (remember to connect via the Bluetooth link, since pluging the USB cable deactivates the camera !!!)

      while [ 1 ]; do cat /tmp/picture | nc 192.168.1.2 1234; done

    Run these two commands in two different shells on the remote Ubuntu computer:

      mkfifo /tmp/rollingspiderpicture ; while [ 1 ]; do nc -l 1234 > /tmp/rollingspiderpicture; done
      mplayer -demuxer rawvideo -rawvideo w=160:h=120:format=yuy2 -loop 0 /tmp/rollingspiderpicture

    */

    //stream image
    //-----------

    if ((FEAT_IMSAVE == 2) && ((counter % 60) == 0) && (NULL != image)) //@pseudo1Hz
    {
        printf("image_proc(): Write image to fifo...\n");
        mkfifo("/tmp/picture", 0777);
        fifo = open("/tmp/picture", O_WRONLY);
        if (fifo) {
            //char word = "asd";
            //write(fifo,word,320*120);
            write(fifo, buffer, 320 * 120);
            close(fifo);
            usleep(5000);
        }

    }

    //save image
    //-----------

    if ((FEAT_IMSAVE == 1) && ((counter % 6) == 0) && (NULL != image)) //@10Hz
    {
        FILE *data;
        char filename[15];

        sprintf(filename, "/tmp/edu/imgs/img%c.bin", counter);

        mkdir("/tmp/edu", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        mkdir("/tmp/edu/imgs", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        if ((data = fopen(filename, "wb")) == NULL) {
            printf("rsedu_vis(): ERROR opening img file\n");
        }

        fwrite(image, sizeof(pixel2_t) * 80 * 120, 1, data);
        fclose(data);
        usleep(5000);

    }


    usleep(4000);

    //ptiming - store
    //----------
    ptimer_stopstore(FEAT_TIME, counter, start, ptfile);
    //----------


}
